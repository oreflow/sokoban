
/**
 * Lucas!
 *
 * @author Brute Force.
 *         Created Oct 2, 2012.
 */
public class BoxNotFoundException extends Exception{

	/**
	 * Hitta en Boxer går inte... Hund!
	 *
	 * @param msg
	 */
	public BoxNotFoundException(String msg){
		super(msg);
	}

}
